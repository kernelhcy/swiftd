#ifndef __LOG__
#define __LOG__

#include "def.h"

void debug_output(const char *fmt , ...);

#endif
